Use ibm_test;
SELECT
	owner_id,
    owner_name,
    count(category_id) as different_category_count
    FROM owner JOIN article USING(owner_id)
    JOIN category_article_mapping USING (article_id)
    JOIN category USING(category_id)
GROUP BY owner_id
ORDER BY different_category_count DESC
